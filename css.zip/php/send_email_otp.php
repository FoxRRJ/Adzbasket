<?php
session_start();

require "Mail/phpmailer/PHPMailerAutoload.php";
include('connection.php');
$email = $_POST["email"];

$check_query = mysqli_query($connect, "SELECT * FROM login where email ='$email'");
$rowCount = mysqli_num_rows($check_query);



        $result = mysqli_query($connect, "INSERT INTO login (email,status) VALUES ('$email', 0)");

        if($result){
            
            $otp = rand(100000,999999);
            $_SESSION['otp'] = $otp;
            $_SESSION['mail'] = $email;
           
            $mail = new PHPMailer;

            $mail->isSMTP();
            $mail->Host='smtp.gmail.com';
            $mail->Port=587;
            $mail->SMTPAuth=true;
            $mail->SMTPSecure='tls';

            $mail->Username='rahul.nellepalli@gmail.com';
            $mail->Password='paoybeepbcshmqwg';

            $mail->setFrom('rahul.nellepalli@gmail.com', 'OTP Verification');
            $mail->addAddress($_POST["email"]);

            $mail->isHTML(true);
            $mail->Subject="Welcome to Adzbasket";
            $mail->Body="<p>Dear user, </p> <p>Please Enter your OTP $otp and </p> <h3> Start Your AdZ Journey <br></h3>
            ";

            $mail->send();
        }

?>
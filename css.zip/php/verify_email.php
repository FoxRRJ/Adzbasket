<?php
session_start();

include('connection.php');
$otp_code = $_POST["otp"];

$output = "";

if($otp_code != $_SESSION['otp']){
    $output .=  "no";

}else{
    $output .=  "yes";
}

echo json_encode($output);

?>
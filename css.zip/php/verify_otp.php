<?php
session_start();

include('connection.php');

$email_code = $_POST["otp"];
$otp_code = $_POST["mob_otp"];
$email = $_POST["email"];
$phone_no = $_POST["phone_no"];

$output = "";

$session_mobotp = strval($_SESSION['mobotp']); // Convert to string
$session_emailotp = strval($_SESSION['otp']); // Convert to string

$debugData = array(
    "Received OTPs" => array(
        "email" => $email_code,
        "mobile" => $otp_code
    ),
    "Session OTPs" => array(
        "email" => $session_emailotp,
        "mobile" => $session_mobotp
    )
);

if ($otp_code === $session_mobotp && $email_code === $session_emailotp) {
    $output = "Verified";
     // Insert into database
    
    $sql = "insert into userdata (email,phoneno) values ('$email','$phone_no')";
    mysqli_query($connect, $sql);
        
} elseif ($otp_code === $session_mobotp) {
    $output = "Invalid Email OTP";
} elseif ($email_code === $session_emailotp) {
    $output = "Invalid Mobile OTP";
} else {
    $output = "Invalid OTPs";
}

$debugData["Result"] = $output;

echo json_encode(array("output" => $output, "debug" => $debugData));
?>

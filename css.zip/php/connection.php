<?php
require "Mail/phpmailer/PHPMailerAutoload.php";
$dbServername = "localhost";
$dbUsername = "digitaladz412_adzuser";
$dbPassword = "cUnlMP#CG5Ki";
$dbName = "digitaladz412_adz";

$connect = new mysqli($dbServername, $dbUsername, $dbPassword, $dbName);

?>



<?php
session_start();
include('connection.php');

$email = $_POST["email"];
$phone = $_POST['phone_no'];

$mobotp = rand(100000,999999);
$_SESSION['mobotp'] = $mobotp;
$output = "";

/*******************************   send Email otp ******************************************************************* */
$check_query = mysqli_query($connect, "SELECT * FROM login where email ='$email'");
$rowCount = mysqli_num_rows($check_query);



        $result = mysqli_query($connect, "INSERT INTO login (email,status) VALUES ('$email', 0)");

        if($result){
            
            $otp = rand(100000,999999);
            $_SESSION['otp'] = $otp;
            $_SESSION['mail'] = $email;
           
            $mail = new PHPMailer;

            $mail->isSMTP();
            $mail->Host='smtp.gmail.com';
            $mail->Port=587;
            $mail->SMTPAuth=true;
            $mail->SMTPSecure='tls';

            $mail->Username='rahul.nellepalli@gmail.com';
            $mail->Password='paoybeepbcshmqwg';

            $mail->setFrom('rahul.nellepalli@gmail.com', 'OTP Verification');
            $mail->addAddress($_POST["email"]);

            $mail->isHTML(true);
            $mail->Subject="Welcome to Adzbasket";
            $mail->Body="<p>Dear user, </p> <p>Please Enter your OTP $otp and </p> <h3> Start Your AdZ Journey <br></h3>
            ";

            $mail->send();
        }


        $message = "Welcome to Adzbasket, Please Enter your OTP $mobotp and start your AdZ Campaign  ";
        $fields = array(
                "message" => $message,
                "language" => "english",
                "route" => "v3",
                "numbers" => $phone,
                "flash" => "0"
            );
/*******************************   send mobile otp ******************************************************************* */
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_SSL_VERIFYHOST => 0,
      CURLOPT_SSL_VERIFYPEER => 0,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => json_encode($fields),
      CURLOPT_HTTPHEADER => array(
        "authorization:jOlkptces35bmLIDvwxNAhuT8dQzn74CMHWfXBiV6roK2USJ9qjMrf6dHoSCTQiqOsZBwgR14xulty5D",
        "accept: */*",
        "cache-control: no-cache",
        "content-type: application/json"
      ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);
    if ($err) {
        $output .= "no";
    } else {
     
        $output .= "yes";

    }

    echo json_encode($output);


?>
<?php
require "Mail/phpmailer/PHPMailerAutoload.php";

$servername = "localhost";
$username = "digitaladz412_adzuser";
$password = "cUnlMP#CG5Ki";
$dbname = "digitaladz412_adz";



// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
$email = $_POST['email'];
$phoneno =  $_POST['contact-no'];
$output = "";

// Check connection

$check_query = mysqli_query($conn, "SELECT * FROM userdata where email ='$email'");
$rowCount = mysqli_num_rows($check_query);

if($rowCount == 0){

 $mail = new PHPMailer;

$mail->isSMTP();
$mail->Host='smtp.gmail.com';
$mail->Port=587;
$mail->SMTPAuth=true;
$mail->SMTPSecure='tls';

$mail->Username='rahul.nellepalli@gmail.com';
$mail->Password='paoybeepbcshmqwg';

$mail->setFrom('rahul.nellepalli@gmail.com', 'Adzbasket');
$mail->addAddress($email);

$mail->isHTML(true);
$mail->Subject="Welcome to Adzbasket - Let's Get You Started!";
$mail->Body='

<div style="text-align: center;">
<img src="https://adzbasket.io/user/images/AdZlogo.png" style="height: 200px;">
</div>
<div style="text-align: center;padding: 30px;">
<h1>Welcome to Adzbasket!</h1>
</div>

<div style="text-align: center;">
<p style="font-size:larger ;">
    We are so happy to have you on board. Our mission is to make your Advertising campaign experience
    Hassle-free</p>

<h2 style="padding:16px ;">
    ABOUT US:
</h2>

<p style="font-size:larger ;">
    AdzBasket - one of the leading in-app advertising companies partnered with multiple apps for in-app
    advertising
</p>

<h2 style="padding:36px ;padding-bottom:0;">
    Our Offerings:
</h2>

<div>
    <img src="https://adzbasket.io/user/images/offerings.png" style="height: 373px;">
</div>

 <div >
<h2 style="padding: 10px;">Precise targeting:</h2>
<ul style="list-style-type: none;">
    <li style="padding: 5px;font-size:large;padding-left:0;">Access to data, insights & inventory to track
        your campaigns</li>
    <li style="padding: 5px;font-size:large;padding-left:0;">Unbiased approach</li>
    <li style="padding: 5px;font-size:large;padding-left:0;">Dual focus on transparency</li>
</ul>
<h2 style="padding: 10px;">Generate Leads:</h2>
<ul style="list-style-type: none;">
    <li style="padding: 5px;font-size:large;padding-left:0;">Reach out to 492 million+ smartphone users in
        India with us</li>
    <li style="padding: 5px;font-size:large;padding-left:0;">Generate leads by delivering ad campaigns to
        our clients of top brands</li>

</ul>
<h2 style="padding: 10px;">Persuading Brand Solutions:</h2>
<ul style="list-style-type: none;">
    <li style="padding: 5px;font-size:large;padding-left:0;">Understand your audience with us based on
        various factors</li>
    <li style="padding: 5px;font-size:large;padding-left:0;">Increase your user base with various ad formats
        of in-app advertising</li>

</ul>
</div>


<div style="padding-top: 60px;">
    <hr>
    <p>Please do not reply to this mail</p>
    <p>FCI, 50, 2nd Floor, Main Rd, Dooravani Nagar, Bengaluru, Karnataka 560016</p>
    <p><a href="https://adzbasket.io" style="text-decoration: none;">adzbasket.io</a></p>
    <p >View our <span><a href="https://adzbasket.io/terms-and-conditions"  style="text-decoration: none;">Terms of Conditions</a></span> and <span><a href="https://adzbasket.io/privacy-policy" style="text-decoration: none;">Privacy Policy</a></span></p>

</div>



</div>
';

$mail->send();
$output .=  "yes";


}
else{
    $output .=  "no";
}



echo json_encode($output);


?>









                    


              


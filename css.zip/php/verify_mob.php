<?php
session_start();

include('connection.php');
$otp_code = $_POST["mob_otp"];

$output = "";

if($otp_code != $_SESSION['mobotp']){
    $output .=  "no";

}else{
    $output .=  "yes";
}

echo json_encode($output);

?>

<?php
//session start
session_start();


?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Adzbasket</title>
</head>
 <body>

    <div>
        <nav class="navbar fixed-top"
            style="background-color:#0F0F3F;height:64px;width:100%;box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.05);">

        </nav>

    </div>


    <div class="container-fluid my-5  d-flex  justify-content-center">


        <div class="card card-1">

            <div class="main">
                <img class="main-logo" src="img/AdZ logo.png" >
            </div>
            <div class="card-header bg-white">
                <div class="media flex-sm-row flex-column-reverse justify-content-between  ">

                    
                    <div class="col my-auto cust-data">
                        <h4 class="mb-0" style="letter-spacing: 1px;">Thanks for your Order,<span id="cust_name" class="change-color"><?php echo $_SESSION["custname"]; ?></span> !</h4>
                    </div>

                </div>
            </div>
            <div class="card-body">
                <div class="row justify-content-between mb-3">
                    <div class="col-auto">
                        <h6 class="color-1 mb-0 change-color">Order Details</h6>
                    </div>
                    <div class="col-auto  "> <small>Order ID : <span id="ord_id">MOJO2806305A66836003</span></small> </div>
                </div>
                <table style="margin-bottom: 20px;">
                    <tr>
                      <th class="th1">Platform</th>
                      <th class="th2">Ad-Category</th>
                      <th class="th3">Ad-Type</th>
                      <th class="th5">Impressions</th>
                      <th class="th4">Budget</th>
                    </tr>
                    
                  </table>
                
                <div class="row mt-4"  id="sg1" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Disney+ Hotstar.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["disney"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4" id="sg2" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Ola.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["ola"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4" id="sg3" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/paytm/paytm.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["paytm"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4" id="sg4" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Phone Pay.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["phonepe"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4" id="sg5" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Make My Trip.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["mmt"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4" id="sg6" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Go Ibibo.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["ibibo"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4"  id="sg7" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Hungama Bollywood.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["hb"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4"  id="sg8" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Hungama Music.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["hm"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4"  id="sg9" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Paytm Mall.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["pm"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4"  id="sg10" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Rediff.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["rediff"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4"  id="sg11" style="display: none;">
                   
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/swiggy/Swiggy.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                          
                                            <div class="col my-auto"> <small>CPI, CPM </small></div>
                                            <div class="col my-auto"> <small>Video</small></div>
                                            <div class="col my-auto"> <small>456665</small></div>
                                            
                                            <div class="col my-auto">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["swiggy"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                

                            </div>
                        </div>
                    </div>
                    </div>

               

                <div class="row mt-4"  id="sg12" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Tata Croma.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["croma"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4"  id="sg13" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Red Bus.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["rbus"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg14" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Alt Balaji.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["balaji"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div><div class="row mt-4"  id="sg15" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Airtel Xtream.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["ax"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg16" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Airtel Wynk Music.jpg" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["aw"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg17" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Airtel Thanks.jpg" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["at"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg18" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Hungama Games.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["hg"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg19" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Money Control.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["mc"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg20" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Step Set Go.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["ssg"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg21" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Sun NXT.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["snxt"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"   id="sg22" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/The Indian Express.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["ie"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg23" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Zee5.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["zee"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg24" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/Voot.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["voot"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg25" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/mygate.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["mgte"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg26" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/truecaller.webp" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["tcaller"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg27" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/picsart logo.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["part"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4"  id="sg28" style="display: none;">
                    <div class="col">
                        <div class="card card-2">
                            <div class="card-body">
                                <div class="media">
                                    <div class="sq align-self-center "> <img
                                            class="img-fluid  my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0"
                                            src="https://adzbasket.io/img/inshort.png" width="135" height="135" /> </div>
                                    <div class="media-body my-auto text-right">
                                        <div class="row  my-auto flex-column flex-md-row">
                                            
                                            <div class="col my-auto  "> <small>CPM,CPV</small></div>
                                            <div class="col my-auto  "> <small>Banner </small></div>
                                            <div class="col my-auto"> <small>65550</small></div>
                                            
                                            <div class="col my-auto ">
                                                <h6 class="mb-0">&#8377;<?php echo $_SESSION["inshrt"]; ?></h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-4">
                    <div class="col">
                        <div class="row justify-content-between">
                            <div class="col-auto">
                                <p class="mb-1 text-dark"><b>Order Details</b></p>
                            </div>
                            <div class="flex-sm-col text-right col">
                                <p class="mb-1"><b>Total</b></p>
                            </div>
                            <div class="flex-sm-col col-auto">
                                <p id="budget" class="mb-1 ">&#8377;<?php echo $_SESSION["total"]; ?></p>
                            </div>
                        </div>
                        
                        <div class="row justify-content-between">
                            <div class="flex-sm-col text-right col">
                                <p class="mb-1"><b>GST 18%</b></p>
                            </div>
                            <div class="flex-sm-col col-auto">
                                <p id="gst" class="mb-1 ">&#8377;<?php echo $_SESSION["gst"]; ?></p>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <div class="row invoice ">
                    <div class="col">
                        <p class="mb-1">Order ID:<span  id="ord_id1">MOJO2806305A66836003</span></p>
                        <p class="mb-1">Invoice Date : 18 Aug,2022</p>
                        <p class="mb-1">Transaction ID: <span  id="ord_trs_id">	
d5427c0e8e45415f8e4c91e5fe5953af</span></p>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="jumbotron-fluid">
                    <div class="row justify-content-between ">
  
                        <div class="col-auto my-auto ">
                            <h2 class="mb-0 font-weight-bold">TOTAL PAID</h2>
                        </div>
                        <div class="col-auto my-auto ml-auto">
                            <h1 id="total-budget" class="display-3 " style=" font-size:2.5rem;">&#8377; <?php echo $_SESSION["amount"]; ?></h1>
                        </div>
                    </div>
                    <div class="row mb-3 mt-3 mt-md-0">
                        <div class="col-auto border-line"> <small >PAN:AA02hDW7E</small></div>
                        <div class="col-auto border-line"> <small >CIN:UMMC20PTC </small></div>
                        <div class="col-auto "><small class="text-black">GSTN:268FD07EXX </small> </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
             <script src="order.js" charset="utf-8"></script>


        <script>
        
            // var ord_id = localStorage.getItem("order_id");
            // var ord_trs_id = localStorage.getItem("trns_id");
            var c_name  = localStorage.getItem("custr_name");
            var budgetss = localStorage.getItem("budgetvalue");
            var bud_dyn = JSON.parse(budgetss);
            var custname = localStorage.getItem("custr_n");
            var cust_name = JSON.parse(custname);
            var c_name_str  = JSON.parse(c_name);
            
            // var ord_id_str = JSON.parse(ord_id);
            // var ord_trs_id_str = JSON.parse(ord_trs_id);
            // console.log(ord_id_str)
            // console.log(ord_trs_id_str)
              
            var gst = 18 / 100 * bud_dyn;
           
            var total = parseInt(bud_dyn) + gst
            
            
            // document.getElementById("ord_id").innerHTML = ord_id_str;
            // document.getElementById("ord_id1").innerHTML =  ord_id_str;
            // document.getElementById("ord_trs_id").innerHTML = ord_trs_id_str;
            // document.getElementById("cust_name").innerHTML = c_name_str;
            // document.getElementById("budget").innerHTML ="&#8377;" + bud_dyn;
            // document.getElementById("gst").innerHTML = "&#8377;" + gst ;
            // document.getElementById("total-budget").innerHTML = "&#8377;" + total ;
           
    
        </script>

</body>

</html>






















































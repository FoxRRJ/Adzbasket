var ds = localStorage.getItem("datavalue");

var dyn_img = JSON.parse(ds);

console.log(dyn_img);





  if (dyn_img.includes("1")) {
    $("#sg1").show();
  }
  if (dyn_img.includes("2")) {
    $("#sg2").show();
  }
  if (dyn_img.includes("3")) {
    $("#sg3").show();
  }
  if (dyn_img.includes("4")) {
    $("#sg4").show();
  }
  if (dyn_img.includes("5")) {
    $("#sg5").show();
  }
  if (dyn_img.includes("6")) {
    $("#sg6").show();
  }
  if (dyn_img.includes("7")) {
    $("#sg7").show();
  }
  if (dyn_img.includes("8")) {
    $("#sg8").show();
  }
  if (dyn_img.includes("9")) {
    $("#sg9").show();
  }
  if (dyn_img.includes("10")) {
    $("#sg10").show();
  }
  
  if (dyn_img.includes("10")) {
    $("#sg10").show();
  }
  if (dyn_img.includes("12")) {
    $("#sg12").show();
  }
  if (dyn_img.includes("13")) {
    $("#sg13").show();
  }
  if (dyn_img.includes("14")) {
    $("#sg14").show();
  
  }
  if (dyn_img.includes("15")) {
    $("#sg15").show();
  }
  if (dyn_img.includes("16")) {
    $("#sg16").show();
  }
  if (dyn_img.includes("17")) {
    $("#sg17").show();
  }
  if (dyn_img.includes("18")) {
    $("#sg18").show();
  }
  if (dyn_img.includes("19")) {
    $("#sg19").show();
  }
  
  if (dyn_img.includes("20")) {
    $("#sg20").show();
  }
  
  if (dyn_img.includes("21")) {
    $("#sg21").show();
  }
  
  if (dyn_img.includes("22")) {
    $("#sg22").show();
  }
  
  if (dyn_img.includes("23")) {
    $("#sg23").show();
  }
  
  if (dyn_img.includes("24")) {
    $("#sg24").show();
  }
  
  if (dyn_img.includes("25")) {
    $("#sg25").show();
  }
  
  if (dyn_img.includes("26")) {
    $("#sg26").show();
  }
  
  if (dyn_img.includes("27")) {
    $("#sg27").show();
  }
  
  if (dyn_img.includes("28")) {
    $("#sg28").show();
  }
  
  if (dyn_img.includes("29")) {
    $("#sg29").show();
}

if (dyn_img.includes("30")) {
    $("#sg30").show();
}
if (dyn_img.includes("31")) {
    $("#sg31").show();
}
if (dyn_img.includes("32")) {
    $("#sg32").show();
}
if (dyn_img.includes("33")) {
    $("#sg33").show();
}
if (dyn_img.includes("34")) {
    $("#sg34").show();
}
if (dyn_img.includes("35")) {
    $("#sg35").show();
}
if (dyn_img.includes("36")) {
    $("#sg36").show();
}
if (dyn_img.includes("37")) {
    $("#sg37").show();
}
if (dyn_img.includes("38")) {
    $("#sg38").show();
}
if (dyn_img.includes("39")) {
    $("#sg39").show();
}
if (dyn_img.includes("40")) {
    $("#sg40").show();
}
if (dyn_img.includes("41")) {
    $("#sg41").show();
}
if (dyn_img.includes("42")) {
    $("#sg42").show();
}
if (dyn_img.includes("43")) {
    $("#sg43").show();
}
if (dyn_img.includes("44")) {
    $("#sg44").show();
}
if (dyn_img.includes("45")) {
    $("#sg45").show();
}
if (dyn_img.includes("46")) {
    $("#sg46").show();
}
if (dyn_img.includes("47")) {
    $("#sg47").show();
}
if (dyn_img.includes("50")) {
    $("#sg50").show();
}
if (dyn_img.includes("52")) {
    $("#sg52").show();
}
if (dyn_img.includes("55")) {
    $("#sg55").show();
}
if (dyn_img.includes("56")) {
    $("#sg56").show();
}
if (dyn_img.includes("57")) {
    $("#sg57").show();
}
if (dyn_img.includes("58")) {
    $("#sg58").show();
}
if (dyn_img.includes("59")) {
    $("#sg59").show();
}

if (dyn_img.includes("60")) {
    $("#sg60").show();
}

  



<?php 
//session start
session_start();

require("./instamojo-php-0.4/src/Instamojo.php");
require("./credn.php");
require("./connection.php");
//create api object
$api = new Instamojo\Instamojo(API_KEY, AUTH_TOKEN, 'https://test.instamojo.com/api/1.1/');



// echo("<pre>");
// print_r($_GET);
try{
	$payment_req_id = $_GET['payment_request_id'];
	$payment_id = $_GET['payment_id'];
	$payment_status = $_GET['payment_status'];
	$response = $api->paymentRequestPaymentStatus($payment_req_id,$payment_id,$payment_status);
	// echo('<pre>');
	// print_r($response);

///fetching data from response given by instamojo

$status=$response['status'];

if(strcmp($status ,'Failed')==0){
	echo('failed');
}
else{
	//sending data to database

    $name=$_SESSION["custname"];
	$paymode=$response["payment"]["instrument_type"];
	
	$query="INSERT INTO `purchase`(`custname`, `txnid`, `paymentid`,  `paymentmode`) VALUES ('$name','$payment_req_id','$payment_id','$paymode')";

if(mysqli_query($conn,$query)){

// echo "order placed";

}
else{
	echo 'Error' .mysqli_error($conn);
}


}


}catch (Exception $e){

    print('Error:' . $e->getMessage());

}


?>

 
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link href='https://fonts.googleapis.com/css?family=Lato:300,400|Montserrat:700' rel='stylesheet' type='text/css'>
	<style>
		@import url(//cdnjs.cloudflare.com/ajax/libs/normalize/3.0.1/normalize.min.css);
		@import url(//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css);
	</style>
	<link rel="stylesheet" href="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/default_thank_you.css">
	<script src="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/jquery-1.9.1.min.js"></script>
	<script src="https://2-22-4-dot-lead-pages.appspot.com/static/lp918/min/html5shiv.js"></script>
</head>
<body>


	<div>
    <nav class="navbar fixed-top"
        style="background-color:#0F0F3F;height:64px;width:100%;box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.05);">
        <div class="image m-2">

            </a>
        </div>
    </nav>

</div>


	<header class="site-header" id="header">
		<h1 class="site-header__title" data-lead-id="site-header-title">THANK YOU!</h1>
	</header>

	<div class="main-content">
		<i class="fa fa-check main-content__checkmark" id="checkmark"></i>
		<p class="main-content__body" data-lead-id="main-content-body">Please check your email for Invoice and Order Details</p>
	</div>

	<div class="main-content">
		
		<p class="main-content__body" data-lead-id="main-content-body">Click here to view your <span ><a href="order.php">Adzbasket</a></span></p>
	</div>

	<footer class="site-footer" id="footer">
		<p class="site-footer__fineprint" id="fineprint">Copyright ©2022 | All Rights Reserved by <a href="https://adzbasket.io">Adzbasket.io</a></p>
	</footer>
</body>

// <script>
//   localStorage.setItem('order_id', "<?php echo $payment_id;?>");
//   localStorage.setItem('trns_id', "<?php echo $payment_req_id;?>");
// </script>
</html>  

 

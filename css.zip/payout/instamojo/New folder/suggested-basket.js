

/* alert if page reload is triggered to warn changes may be lost*/


window.addEventListener('beforeunload', function (e) {
  // Cancel the event
  e.preventDefault(); // If you prevent default behavior in Mozilla Firefox prompt will always be shown
  // Chrome requires returnValue to be set
  e.returnValue = '';
});


// suggested basket starts /////////////////////////////////////

// document.getElementById("demv").innerHTML = localStorage.getItem("chckdval");
// console.log(localStorage);



var ds = localStorage.getItem("datavalue");
var budgetss = localStorage.getItem("budgetvalue");

var dyn_img = JSON.parse(ds);
console.log(dyn_img)
var dyn_img_temp_array = dyn_img;
console.log(dyn_img_temp_array)


var bud_dyn = JSON.parse(budgetss);



$('.bud').html(bud_dyn + "+" +"18% GST");   /* retrieving budget value entered budget section frm campaign page and dynamically updating it in total amount section in suggested basket page  */


var lengthany = dyn_img.length;

var budget_data = Math.floor(bud_dyn / lengthany);
$('.bd-data').attr('placeholder', budget_data);





if (dyn_img.includes("1")) {
  $("#sg1").show();
}
if (dyn_img.includes("2")) {
  $("#sg2").show();
}
if (dyn_img.includes("3")) {
  $("#sg3").show();
}
if (dyn_img.includes("4")) {
  $("#sg4").show();
}
if (dyn_img.includes("5")) {
  $("#sg5").show();
}
if (dyn_img.includes("6")) {
  $("#sg6").show();
}
if (dyn_img.includes("7")) {
  $("#sg7").show();
}
if (dyn_img.includes("8")) {
  $("#sg8").show();
}
if (dyn_img.includes("9")) {
  $("#sg9").show();
}
if (dyn_img.includes("10")) {
  $("#sg10").show();
}

if (dyn_img.includes("10")) {
  $("#sg10").show();
}
if (dyn_img.includes("12")) {
  $("#sg12").show();
}
if (dyn_img.includes("13")) {
  $("#sg13").show();
}
if (dyn_img.includes("14")) {
  $("#sg14").show();
} if (dyn_img.includes("15")) {
  $("#sg15").show();
}
if (dyn_img.includes("16")) {
  $("#sg16").show();
}
if (dyn_img.includes("17")) {
  $("#sg17").show();
}
if (dyn_img.includes("18")) {
  $("#sg18").show();
}
if (dyn_img.includes("19")) {
  $("#sg19").show();
}

if (dyn_img.includes("20")) {
  $("#sg20").show();
}

if (dyn_img.includes("21")) {
  $("#sg21").show();
}

if (dyn_img.includes("22")) {
  $("#sg22").show();
}

if (dyn_img.includes("23")) {
  $("#sg23").show();
}

if (dyn_img.includes("24")) {
  $("#sg24").show();
}

if (dyn_img.includes("25")) {
  $("#sg25").show();
}

if (dyn_img.includes("26")) {
  $("#sg26").show();
}

if (dyn_img.includes("27")) {
  $("#sg27").show();
}

if (dyn_img.includes("28")) {
  $("#sg28").show();
}


/* based on  budget allocated calculate the impressions formula Impressions = Budget/ CPM * 1000   */


function impresion() {
  var olaImpression = Math.round(budget_data / 332 * 1000);
  var swiggyImp = Math.round(budget_data / 108 * 1000);
  var paytmImp = Math.round(budget_data / 250 * 1000);
  var phonepeImp = Math.round(budget_data / 201 * 1000);
  var mcImp = Math.round(budget_data / 231 * 1000);
  var mmtImp = Math.round(budget_data / 228 * 1000);
  var vootImp = Math.round(budget_data / 94 * 1000);
  var airtelxImp = Math.round(budget_data / 216 * 1000);
  var airtelwImp = Math.round(budget_data / 216 * 1000);
  var airteltImp = Math.round(budget_data / 216 * 1000);
  var zee5Imp = Math.round(budget_data / 112 * 1000);
  var hotstarImp = Math.round(budget_data / 52 * 1000);
  var mygateImp = Math.round(budget_data / 16 * 1000);
  var inshortsImp = Math.round(budget_data / 360 * 1000);
  var cromaImp = Math.round(budget_data / 222 * 1000);
  var truecallerImp = Math.round(budget_data / 65 * 1000);
  var picsartImp = Math.round(budget_data / 6 * 1000);
  var expressImp = Math.round(budget_data / 140 * 1000);
  var ssgImp = Math.round(budget_data / 100 * 1000);
  var rediffImp = Math.round(budget_data / 140 * 1000);
  var sunxtImp = Math.round(budget_data / 442 * 1000);
  var hbImp = Math.round(budget_data / 160 * 1000);
  var hmImp = Math.round(budget_data / 160 * 1000);
  var altImp = Math.round(budget_data / 5 * 1000);


  $('.olati').html(olaImpression);
  $('.swiggyti').html(swiggyImp);
  $('.paytmti').html(paytmImp);
  $('.phonepeti').html(phonepeImp);
  $('.mcti').html(mcImp);
  $('.vootti').html(vootImp);
  $('.mmtti').html(mmtImp);
  $('.airtelxImpti').html(airtelxImp);
  $('.airtelwImpti').html(airtelwImp);
  $('.airteltImpti').html(airteltImp);
  $('.zee5Impti').html(zee5Imp);
  $('.disneyti').html(hotstarImp);
  $('.mygateImpti').html(mygateImp);
  $('.inshortsImpti').html(inshortsImp);
  $('.cromaImpti').html(cromaImp);
  $('.truti').html(truecallerImp);
  $('.picsti').html(picsartImp);
  $('.expressti').html(expressImp);
  $('.ssgti').html(ssgImp);
  $('.rediffti').html(rediffImp);
  $('.sunxtti').html(sunxtImp);
  $('.hbti').html(hbImp);
  $('.hmti').html(hmImp)
  $('.altti').html(altImp)
}
impresion()

/** impression calculation ends */


/*  function toremove a value from an array   */

function remove_array_value(array, value) {
  var index = array.indexOf(value);
  if (index >= 0) {
    array.splice(index, 1);
    reindex_array(array);
  }
}

function reindex_array(array) {
  var result = [];
  for (var key in array) {
    result.push(array[key]);
  }
  return result;
}


$(document).ready(function () {

  $(".del").click(function () {

    var del_id = [];


    var clicked_ids = ($(this).attr("id")); /* get the id of button clicked  */

    del_id.push(clicked_ids)

    var str_del_id = del_id.toString(); /* convert the id clicked into string to pass it as a value to remove from array function   */

    var del_img = "sg" + del_id;  /* creating a variable to create a clone of the id value of div in basket page */

    $("#" + del_img).hide();


    remove_array_value(dyn_img, str_del_id);
    /* after remving the value from array recalculate the array length and divide the budget received from campaign page  equally to number of divs present*/
    var length1 = dyn_img.length;
    console.log(length1)
    var budget_data1 = Math.floor(bud_dyn / length1);
    console.log(budget_data1)
    $('.bd-data').attr('placeholder', budget_data1);





    var olaImpression = Math.round(budget_data1 / 332 * 1000);
    var swiggyImp = Math.round(budget_data1 / 108 * 1000);
    var paytmImp = Math.round(budget_data1 / 250 * 1000);
    var phonepeImp = Math.round(budget_data1 / 201 * 1000);
    var mcImp = Math.round(budget_data1 / 231 * 1000);
    var mmtImp = Math.round(budget_data1 / 228 * 1000);
    var vootImp = Math.round(budget_data1 / 94 * 1000);
    var airtelxImp = Math.round(budget_data1 / 216 * 1000);
    var airtelwImp = Math.round(budget_data1 / 216 * 1000);
    var airteltImp = Math.round(budget_data1 / 216 * 1000);
    var zee5Imp = Math.round(budget_data1 / 112 * 1000);
    var hotstarImp = Math.round(budget_data1 / 52 * 1000);
    var mygateImp = Math.round(budget_data1 / 16 * 1000);
    var inshortsImp = Math.round(budget_data1 / 360 * 1000);
    var cromaImp = Math.round(budget_data1 / 222 * 1000);
    var truecallerImp = Math.round(budget_data1 / 65 * 1000);
    var picsartImp = Math.round(budget_data1 / 6 * 1000);
    var expressImp = Math.round(budget_data1 / 140 * 1000);
    var ssgImp = Math.round(budget_data1 / 100 * 1000);
    var rediffImp = Math.round(budget_data1 / 140 * 1000);
    var sunxtImp = Math.round(budget_data1 / 442 * 1000);
    var hbImp = Math.round(budget_data1 / 160 * 1000);
    var hmImp = Math.round(budget_data1 / 160 * 1000);
    var altImp = Math.round(budget_data1 / 5 * 1000);


    $('.olati').html(olaImpression);
    $('.swiggyti').html(swiggyImp);
    $('.paytmti').html(paytmImp);
    $('.phonepeti').html(phonepeImp);
    $('.mcti').html(mcImp);
    $('.vootti').html(vootImp);
    $('.mmtti').html(mmtImp);
    $('.airtelxImpti').html(airtelxImp);
    $('.airtelwImpti').html(airtelwImp);
    $('.airteltImpti').html(airteltImp);
    $('.zee5Impti').html(zee5Imp);
    $('.disneyti').html(hotstarImp);
    $('.mygateImpti').html(mygateImp);
    $('.inshortsImpti').html(inshortsImp);
    $('.cromaImpti').html(cromaImp);
    $('.truti').html(truecallerImp);
    $('.picsti').html(picsartImp);
    $('.expressti').html(expressImp);
    $('.ssgti').html(ssgImp);
    $('.rediffti').html(rediffImp);
    $('.sunxtti').html(sunxtImp);
    $('.hbti').html(hbImp);
    $('.hmti').html(hmImp)
    $('.altti').html(altImp)



  });

});




/* divinding budget equall to different platforms based on output we get after filteration from campaign page */





/////////////////////>>>>>>>>>>>>>>>>>>> for multiplemodal popups based on data target >>>>>>>>>>>>>>>>>>>>>>

var modalbtns = document.querySelectorAll(".popup")

modalbtns.forEach(function (btn) {
  btn.onclick = function () {
    var modal = btn.getAttribute("data-target");

    // document.getElementById(modal).style.display = "block";

  };
});




// to enable editing of budget //////////////////////////////////

$(document).ready(function () {
  $("#disney-btn").click(function () {
    $('.disneybudget').prop('readonly', false).focus();


  });

  $("#ola-btn").click(function () {
    $('.ola').prop('readonly', false).focus();
  });

  $("#paytm-btn").click(function () {
    $('.paytm').prop('readonly', false).focus();
  });

  $("#phone-pay-btn").click(function () {
    $('.phone-pay').prop('readonly', false).focus();
  });

  $("#mmt-btn").click(function () {
    $('.mmt-budget').prop('readonly', false).focus();
  });

  $("#ibibo-btn").click(function () {
    $('.ibibo-budget').prop('readonly', false).focus();
  });

  $("#hb-btn").click(function () {
    $('.bolly-budget').prop('readonly', false).focus();
  });

  $("#hm-btn").click(function () {
    $('.bollymusic-budget').prop('readonly', false).focus();
  });


  $("#pm-btn").click(function () {
    $('.mall-budget').prop('readonly', false).focus();
  });


  $("#rediff-btn").click(function () {
    $('.red-budget').prop('readonly', false).focus();
  });

  $("#swiggy-btn").click(function () {
    $('.swig-budget').prop('readonly', false).focus();
  });

  $("#tata-btn").click(function () {
    $('.tata-budget').prop('readonly', false).focus();
  });

  $("#rbus-btn").click(function () {
    $('.rbus-budget').prop('readonly', false).focus();
  });

  $("#alt-btn").click(function () {
    $('.alt-budget').prop('readonly', false).focus();
  });

  $("#xt-btn").click(function () {
    $('.xt-budget').prop('readonly', false).focus();
  });

  $("#wyn-btn").click(function () {
    $('.wyn-budget').prop('readonly', false).focus();
  });

  $("#thnx-btn").click(function () {
    $('.thnx-budget').prop('readonly', false).focus();
  });

  $("#games-btn").click(function () {
    $('.games-budget').prop('readonly', false).focus();
  });

  $("#mc-btn").click(function () {
    $('.mc-budget').prop('readonly', false).focus();
  });

  $("#ssg-btn").click(function () {
    $('.ssg-budget').prop('readonly', false).focus();
  });
  $("#sn-btn").click(function () {
    $('.sn-budget').prop('readonly', false).focus();
  });

  $("#ie-btn").click(function () {
    $('.ie-budget').prop('readonly', false).focus();
  });

  $("#zee-btn").click(function () {
    $('.zee-budget').prop('readonly', false).focus();
  });

  $("#vt-btn").click(function () {
    $('.vt-budget').prop('readonly', false).focus();
  });

  $("#mg-btn").click(function () {
    $('.mg-budget').prop('readonly', false).focus();
  });

  $("#tc-btn").click(function () {
    $('.tc-budget').prop('readonly', false).focus();
  });

  $("#part-btn").click(function () {
    $('.part-budget').prop('readonly', false).focus();
  });

  $("#inshot-btn").click(function () {
    $('.inshot-budget').prop('readonly', false).focus();
  });

});





// editing budget ends /////////////////////////////////////


// CALCULATING IMPRESSIONS //////////////////////////



/**   creating a function to dynamically input the budget that we edit using edit button -- */

/**  to change the impression based on the amount we get */



$(document).ready(function () {
  
  $(".edit-button-logo").click(function () {

    var edit_id = [];


    var clicked_edit_ids = ($(this).attr("data-category")); /* get the id of button clicked  */

    edit_id.push(clicked_edit_ids)

    console.log(edit_id)


    var edit_id_length = edit_id.length;
    console.log(edit_id_length)

    var str_edit_id = edit_id.toString(); /* convert the id clicked into string to pass it as a value to remove from array function   */

   


    remove_array_value(dyn_img_temp_array, str_edit_id);
    /* after remving the value from array recalculate the array length and divide the budget received from campaign page  equally to number of divs present*/
    var length_edited = dyn_img_temp_array.length;
    console.log(length_edited)
    
   
   
  

  });

});


function changeEditImp(value) {

  var olaImpressionv = Math.round(value / 332 * 1000);
  var swiggyImpv = Math.round(value / 108 * 1000);
  var paytmImpv = Math.round(value / 250 * 1000);
  var phonepeImpv = Math.round(value / 201 * 1000);
  var mcImpv = Math.round(value / 231 * 1000);
  var mmtImpv = Math.round(value / 228 * 1000);
  var vootImpv = Math.round(value / 94 * 1000);
  var airtelxImpv = Math.round(value / 216 * 1000);
  var airtelwImpv = Math.round(value / 216 * 1000);
  var airteltImpv = Math.round(value / 216 * 1000);
  var zee5Impv = Math.round(value / 112 * 1000);
  var hotstarImpv = Math.round(value / 52 * 1000);
  var mygateImpv = Math.round(value / 16 * 1000);
  var inshortsImpv = Math.round(value / 360 * 1000);
  var cromaImpv = Math.round(value / 222 * 1000);
  var truecallerImpv = Math.round(value / 65 * 1000);
  var picsartImpv = Math.round(value / 6 * 1000);
  var expressImpv = Math.round(value / 140 * 1000);
  var ssgImpv = Math.round(value / 100 * 1000);
  var rediffImpv = Math.round(value / 140 * 1000);
  var sunxtImpv = Math.round(value / 442 * 1000);
  var hbImpv = Math.round(value / 160 * 1000);
  var hmImpv = Math.round(value / 160 * 1000);
  var altImpv = Math.round(value / 5 * 1000);


  $('.olati').html(olaImpressionv);
  $('.swiggyti').html(swiggyImpv);
  $('.paytmti').html(paytmImpv);
  $('.phonepeti').html(phonepeImpv);
  $('.mcti').html(mcImpv);
  $('.vootti').html(vootImpv);
  $('.mmtti').html(mmtImpv);
  $('.airtelxImpti').html(airtelxImpv);
  $('.airtelwImpti').html(airtelwImpv);
  $('.airteltImpti').html(airteltImpv);
  $('.zee5Impti').html(zee5Impv);
  $('.disneyti').html(hotstarImpv);
  $('.mygateImpti').html(mygateImpv);
  $('.inshortsImpti').html(inshortsImpv);
  $('.cromaImpti').html(cromaImpv);
  $('.truti').html(truecallerImpv);
  $('.picsti').html(picsartImpv);
  $('.expressti').html(expressImpv);
  $('.ssgti').html(ssgImpv);
  $('.rediffti').html(rediffImpv);
  $('.sunxtti').html(sunxtImpv);
  $('.hbti').html(hbImpv);
  $('.hmti').html(hmImpv)
  $('.altti').html(altImpv)

}

function ola(ele) {
  var x = ele.value;
  var olaImpression = Math.floor(x / 332 * 1000);
  if (event.key === 'Enter') {
    $('.olati').html(olaImpression);
  }
}

function swiggy(ele) {
  var x = ele.value;
  var swiggyImpression = Math.floor(x / 108 * 1000);
  if (event.key === 'Enter') {
    $('.swiggyti').html(swiggyImpression);
  }

}

function paytm(ele) {
  var x = ele.value;

  var paytmImpression = Math.floor(x / 250 * 1000);

  if (event.key === 'Enter') {
    $('.paytmti').html(paytmImpression);
  }

}

function phonepe(ele) {
  var x = ele.value;
  var phonepeImpression = Math.floor(x / 201 * 1000);
  if (event.key === 'Enter') {
    $('.phonepeti').html(phonepeImpression);
  }

}

function mc(ele) {
  var x = ele.value;
  var mcImpression = Math.floor(x / 231 * 1000);
  if (event.key === 'Enter') {
    $('.mcti').html(mcImpression);
  }

}

function mmt(ele) {
  var x = ele.value;
  var mmtImpression = Math.floor(x / 228 * 1000);
  if (event.key === 'Enter') {
    $('.mmtti').html(mmtImpression);
  }

}

function voot(ele) {
  var x = ele.value;
  var vootImpression = Math.floor(x / 94 * 1000);
  if (event.key === 'Enter') {
    $('.vootti').html(vootImpression);
  }

}

function airtelx(ele) {
  var x = ele.value;
  var airtelImpression = Math.floor(x / 216 * 1000);
  if (event.key === 'Enter') {
    $('.airtelxImpti').html(airtelImpression);
  }

}
function airtelw(ele) {
  var x = ele.value;
  var airtelImpression = Math.floor(x / 216 * 1000);
  if (event.key === 'Enter') {
    $('.airtelwImpti').html(airtelImpression);
  }
  

}
function airtelt(ele) {
  var x = ele.value;
  var airtelImpression = Math.floor(x / 216 * 1000);
  if (event.key === 'Enter') {
    $('.airteltImpti').html(airtelImpression);
  }

}
function zee(ele) {
  var x = ele.value;
  var zeeImpression = Math.floor(x / 112 * 1000);
  if (event.key === 'Enter') {
    $('.mmtti').html(zeeImpression);
  }

}

function disney(ele) {
  var x = ele.value;

  var disneyImpression = Math.floor(x / 52 * 1000);


  if (event.key === 'Enter') {
    var edit_dis = x - bud_dyn;

    console.log(edit_dis)
    var budget_datadis = Math.abs(edit_dis / length_edited);
    console.log(budget_datadis)
    $('.bd-data').attr('placeholder', budget_datadis);
    changeEditImp(budget_datadis)
    $('.disneyti').html(disneyImpression);
  }
}

function mygate(ele) {
  var x = ele.value;
  var mygImpression = Math.floor(x / 16 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.mygateImpti').html(mygImpression);
  }
}

function inshort(ele) {
  var x = ele.value;
  var inshortImpression = Math.floor(x / 360 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.inshortsImpti').html(inshortImpression);
  }
}

function croma(ele) {
  var x = ele.value;
  var cromaImpression = Math.floor(x / 222 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.cromaImpti').html(cromaImpression);
  }
}

function trucaller(ele) {
  var x = ele.value;
  var trucallerImpression = Math.floor(x / 65 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.truti').html(trucallerImpression);
  }
}
function picksart(ele) {
  var x = ele.value;
  var picImpression = Math.floor(x / 6 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.picsti').html(picImpression);
  }
}


function express(ele) {
  var x = ele.value;
  var expressImpression = Math.floor(x / 140 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.expressti').html(expressImpression);
  }
}

function ssg(ele) {
  var x = ele.value;
  var ssgImpression = Math.floor(x / 100 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.ssgti').html(ssgImpression);
  }
}

function rediff(ele) {
  var x = ele.value;
  var rediffImpression = Math.floor(x / 140 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.rediffti').html(rediffImpression);
  }
}

function sunxt(ele) {
  var x = ele.value;
  var sunxtImpression = Math.floor(x / 442 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.sunxtti').html(sunxtImpression);
  }
}


function hb(ele) {
  var x = ele.value;
  var hbImpression = Math.floor(x / 160 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.hbti').html(hbImpression);
  }
}


function hm(ele) {
  var x = ele.value;
  var hmImpression = Math.floor(x / 160 * 1000);

  if (event.key === 'Enter') {
    // alert(x);
    $('.hmti').html(hmImpression);
  }
}

function alt(ele) {
  var x = ele.value;
  var altImpression = Math.floor(x / 5 * 1000);

  if (event.key === 'Enter') {
    // alert(x);


    var edit_alt = x - bud_dyn;

    console.log(edit_alt)
    var budget_dataalt = Math.abs(edit_alt / length_edited);
    console.log(budget_dataalt)
    $('.bd-data').attr('placeholder', budget_dataalt);
    changeEditImp(budget_dataalt)
    $('.altti').html(altImpression);
  }
}




// END----------------------------//////////////////////

// Create Your own Basket ////////////////////////////////////////////////////////////////

var txt = document.getElementById("bskt-btn");
$(document).ready(function () {
  $("#bskt-btn").click(function () {

    $(".airtel-btn").text("ADDED");
    $(".airtel-btn").addClass("blur");

  });

  $("#abl").click(function () {

    $(".alt-balaji").text("ADDED");
    $(".alt-balaji").addClass("blur");

  });

  $("#dh").click(function () {

    $(".disney").text("ADDED");
    $(".disney").addClass("blur");

  });

  $("#mmtp").click(function () {

    $(".mmt-bskt").text("ADDED");
    $(".mmt-bskt").addClass("blur");

  });

  $("#ol").click(function () {

    $(".ola-bskt").text("ADDED");
    $(".ola-bskt").addClass("blur");

  });

  $("#paym").click(function () {

    $(".paytm-bskt").text("ADDED");
    $(".paytm-bskt").addClass("blur");

  });

  $("#athnx").click(function () {

    $(".airtel-tnx").text("ADDED");
    $(".airtel-tnx").addClass("blur");

  });

  $("#mctrl").click(function () {

    $(".money-control").text("ADDED");
    $(".money-control").addClass("blur");

  });

  $("#swig").click(function () {

    $(".swiggy-bskt").text("ADDED");
    $(".swiggy-bskt").addClass("blur");

  });

  $("#rb").click(function () {

    $(".red-bus").text("ADDED");
    $(".red-bus").addClass("blur");

  });

  $("#vto").click(function () {

    $(".voot").text("ADDED");
    $(".voot").addClass("blur");

  });

  $("#ibi").click(function () {

    $(".ibibo").text("ADDED");
    $(".ibibo").addClass("blur");

  });

});



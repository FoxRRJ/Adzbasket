<?php
$conn=mysqli_connect('localhost','digitaladz412_payment','RT?k]A?xnXW3','digitaladz412_paymentgateway');
if(!$conn){
  die('Connection failed: '.mysqli_connect_error());
}

//echo('Connected');
?>
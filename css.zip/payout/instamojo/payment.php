<?php
//session start
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="../../favicon.ico">
	<title>Payment Mojo</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>




</head>

<body>

	<div>
		<nav class="navbar fixed-top"
			style="background-color:#0F0F3F;height:50px;width:100%;box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.05);">
			<div class="image m-2">

			</div>
		</nav>

	</div>

<div class="container" >
		<div class="col-md-4" style="margin: auto; float:none;border-radius: 10px;border-style: ridge;margin-bottom: 8px;">

			<div class="page-header" style="margin-top: 0;"> 
				<div class="page-header-img" style="text-align: center;">
					<img src="img/AdZ logo.png" style="height: 175px;">
				</div>
				<h1 style="text-align: center;padding-bottom: 6px;">Adzbasket Payment</h1>
				<form action="pay.php" method="post" accept-charset="utf-8">

					<div class="form-group">
						<label>Your Name</label>
						<input id="c-name" type="text" class="form-control" name="name" placeholder="Enter your name" Value="" readonly>
					</div>
					<div class="form-group">
						<label>Your Phone</label>
						<input id="c-no" type="text" class="form-control" name="phoneno" placeholder="Enter your phone number" Value="" readonly>
					</div>
					<div class="form-group">
						<label>Your Email</label>
						<input id="c-email" type="email" class="form-control" name="emailid" placeholder="Enter you email"  Value="" readonly>
					</div>
					<div class="form-group">
						<label>Amount</label>
						<input id="get-budget" type="email" class="form-control" name="amount" Value="" readonly>
					</div>
					<p style="text-align: center;"><input type="submit" class="btn  btn-lg" value="Pay Now" style="padding:10px 80px; background-color: #0F0F3F;color: white;"></p>
				</form>

			</div>
		</div> <!-- /container -->
	</div>



	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
		integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
		crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
		integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
		crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
		integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s"
		crossorigin="anonymous"></script>
	<script>

        
		 var c_email = localStorage.getItem("custr_mail");
		 var c_no = localStorage.getItem("custr_no");
		 var c_name = localStorage.getItem("custr_name");
		 var c_amount = localStorage.getItem("budgetsumdata");
		 
	

         
		var c_email_str = JSON.parse(c_email);
		var c_no_str    = JSON.parse(c_no);
		var c_name_str  = JSON.parse(c_name);
	    var c_amt_str  = JSON.parse(c_amount);
		
          
       
        

       
		document.getElementById("c-name").value = c_name_str ;
		document.getElementById("c-email").value = c_email_str ;
		document.getElementById("c-no").value = c_no_str ;
		document.getElementById("get-budget").value = c_amt_str ;

	</script>
</body>

</html>
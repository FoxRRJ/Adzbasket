<?php

//session start
session_start();

require("./instamojo-php-0.4/src/Instamojo.php");
require("./credn.php");
//create api object
$api = new Instamojo\Instamojo(API_KEY, AUTH_TOKEN, 'https://www.instamojo.com/api/1.1/');

//fetchn data from the form
$amount=$_POST["amount"];
$email=$_POST["emailid"];
$phone=$_POST["phoneno"];
$name=$_POST["name"];

//storing details in session

$_SESSION["custname"]=$name;
$_SESSION["amount"]=$amount;
$_SESSION["email"]=$email;
$_SESSION["phone"]=$phone;

//1. payment request creation
try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => "Adzbasket",
        "buyer_name" => $name,
        "amount" => $amount,
        "phone" => $phone,
        "send_email" => true,
        "email" => $email,
        "redirect_url" => "https://adzbasket.io/payout/instamojo/success.php"
        ));

        // echo("<pre>");
        // print_r($response);
   $url=$response["longurl"];
   header("location:$url");
   
}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}

?>
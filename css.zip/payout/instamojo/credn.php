<?php
define("API_KEY","570a8654cbc0cc416d86f31fa20fe9eb");
define("AUTH_TOKEN","4902754bdadbedf84f04d14e85debcd7");

?>



